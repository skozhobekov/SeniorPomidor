bugs = {"id":"1", "name":"bug1", "status":"highest"}

print(bugs)

bugs["status"] = ["lowest"]
print(bugs)