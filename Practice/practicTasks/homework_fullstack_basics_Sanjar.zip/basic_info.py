name = str(input("Введите имя: "))
occupation = str(input("Введите профессию: "))
ifKnowValue = str(input("Знаете что такое переменная"))


if ifKnowValue == "da":
    print("У Вас внушительный опыт")
elif ifKnowValue=="net":
    print("Мы вынуждены отказать")
